package com.jio.dap.pmapi.dataaccess;


import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TimeZone;
import java.util.stream.Collectors;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jio.dap.pmapi.config.JmsPublisher;
import com.jio.dap.pmapi.config.JsonParser;
import com.jio.dap.pmapi.config.RestCall;
import com.jio.dap.pmapi.config.SolacePublisher;
import com.jio.dap.pmapi.datamodels.Details;
import com.jio.dap.pmapi.datamodels.LineDetails;
import com.jio.dap.pmapi.datamodels.Milestone;
import com.jio.dap.pmapi.datamodels.Summary;
import com.jio.dap.pmapi.exceptions.CustomAppException;
import com.jio.dap.pmapi.exceptions.FileNotExistException;
import com.jio.dap.pmapi.exceptions.NoRecordsException;

@Component
@SuppressWarnings("unchecked")
public class RequestsProcessing implements ProcessMonitoringInterface {
	@Autowired
	com.jio.dap.pmapi.config.HiveQueryProcess HiveQueryProcess;
	
	SolacePublisher solacePublisher=new SolacePublisher();
	JmsPublisher jmsPublisher=new JmsPublisher();
	@Autowired
	RestCall restCall;
	
	@Autowired
	JsonParser jsonParser;
	
	

	@SuppressWarnings("rawtypes")
	public JSONArray TrackingProcess(JSONObject trackingRequest, JSONObject payload) throws NoRecordsException, FileNotExistException {
		TimeZone.setDefault(TimeZone.getTimeZone("IST"));
		JSONArray trackingResponse;
		Timestamp currentTime=new Timestamp(System.currentTimeMillis());
		String parseSeq = (String) payload.get("parseseq");
		String uniqueColumn = (String) payload.get("uniquecolumn");
		JSONObject fields = (JSONObject) payload.get("fields");
		String seq=" and "+payload.get("minParseSeq")+"<=sequence<="+parseSeq;
		StringBuilder t1filter=new StringBuilder();
		StringBuilder t2filter=new StringBuilder();
		StringBuilder t3filter=new StringBuilder();
		String limit = "50";
		String fromtime = "";
		String totime = "";
		String partitionDate;
		String currentDate;
		String dashboard=trackingRequest.get("dashboard").toString();
		String qString="";
		if(payload.get("qstring")!=null) {
			qString=" and processstate='"+payload.get("qstring").toString()+"'";
		}
		
		for (Object key : trackingRequest.entrySet()) {
			System.out.println("key" + key);
			Map.Entry entry = (Map.Entry) key;
			String keyStr = (String) entry.getKey();
			if (fields.containsKey(keyStr)) {
				keyStr = fields.get(keyStr).toString();
			}
			String keyvalue = (String) entry.getValue();
			if (keyvalue != null && !(keyvalue.isEmpty())) {
				switch (keyStr) {
				case "referenceno":
					t1filter.append(" and " + keyStr + " LIKE '" + keyvalue + "%'");

					t2filter.append(" and " + keyStr + " LIKE '" + keyvalue + "%'");
					t3filter.append(" and " + keyStr + " LIKE '" + keyvalue + "%'");
					break;
				case "dashboard":
					t1filter.append(" and " + keyStr + " LIKE '" + keyvalue + "%'");
					t2filter.append(" and " + keyStr + " LIKE '" + keyvalue + "%'");
					t3filter.append(" and " + keyStr + " LIKE '" + keyvalue + "%'");
					break;
				case "processstate":
					t2filter.append(" and " + keyStr + "='" + keyvalue + "'");
					break;
				case "numberofrows":
					limit = keyvalue;
					break;
				case "fromtimestamp":
					fromtime = keyvalue;
					break;
				case "totimestamp":
					totime = keyvalue;
					break;
				
				default:
					if(dashboard.equalsIgnoreCase("billplanchange") && trackingRequest.containsKey("serviceid")) {
						t3filter.append(" and " + keyStr + " LIKE '%" + keyvalue + "%'");
					}else {
					t3filter.append(" and " + keyStr + "='" + keyvalue + "'");
					}
					break;
				}

			}

		}
		if(fromtime.substring(0, 10).equals(totime.substring(0, 10))) {
			partitionDate="cast(processdate as date) = cast('"+fromtime.substring(0, 10)+"' as date)";
		}else {
			partitionDate="cast(processdate as date) between cast('"+fromtime.substring(0, 10)+"' as date) and cast('"+totime.substring(0, 10)+"' as date) ";
		}
		String time=partitionDate+" and cast(processtimestamp as timestamp) between cast('"+fromtime + "' as timestamp) and cast('" + totime+"' as timestamp) ";
		if(currentTime.toString().substring(0, 10).equals(fromtime.substring(0,10))) {
			currentDate="cast(processdate as date) = cast('"+fromtime.substring(0, 10)+"' as date)";
		}else {
			currentDate="cast(processdate as date) between cast('"+fromtime.substring(0, 10)+"' as date) and cast('"+currentTime.toString().substring(0, 10)+"' as date) ";
		}
		String t1 = "select "+uniqueColumn+",max(processtimestamp) as time from " + payload.get("pmctable")
				+ " where "+currentDate+ t1filter.toString() +seq+ " group by "+uniqueColumn;
		String t2 = "select * from " + payload.get("pmctable")
				+ " where "+currentDate+ t2filter.toString();
		String t3 = "select * from " + payload.get("pmctable")
				+ " where "+currentDate+" and sequence<=" + parseSeq + " " + t3filter.toString() + "";
		String t4 = "select "+uniqueColumn+",max(processtimestamp) as time from " + payload.get("pmctable")
		+ " where "+currentDate + t1filter.toString() + " and sequence<=" + parseSeq +qString+ " group by "+uniqueColumn;
		String t5="select DISTINCT "+uniqueColumn+" from "+payload.get("pmctable")+" where "+time+t1filter.toString()+" and sequence<="+parseSeq;

		ArrayList<String> al = (ArrayList<String>) payload.get("trackingResponse");
		StringBuilder select = new StringBuilder();
		for (String key : al) {
			String keyStr = key;
			if (fields.containsKey(key)) {
				keyStr = fields.get(key).toString();
			}
			switch (key) {
			case "processstate":
				select.append(", t2." + keyStr + " as " + key);
				break;
			case "processtimestamp":
				select.append(", t2." + keyStr + " as " + key);
				break;
			default:
				select.append(", t3." + keyStr + " as " + key);
			}
		}

		String finalQuery = "select " + select.toString().substring(1) + " from (" + t1 + ") t1, (" + t2 + ") t2,(" + t3
				+ ") t3, ("+t4+ ") t4, ("+t5+") t5 where t1."+uniqueColumn+"=t5."+uniqueColumn+"   and t3."+uniqueColumn+"=t1."+uniqueColumn+" and t4."+uniqueColumn+"=t1."+uniqueColumn+" and t2."+uniqueColumn+"=t1."+uniqueColumn+" and t1.time=t2.processtimestamp and t4.time=t3.processtimestamp order by processtimestamp desc LIMIT "
				+ limit;
		System.out.println("quryy"+finalQuery);
		
		trackingResponse = HiveQueryProcess.QueryProcess(finalQuery, al,fields,"tracking");
		return trackingResponse;
	}

	@Override
	public JSONArray SummaryProcess(JSONObject dashboardRequest, JSONObject payload) throws NoRecordsException, FileNotExistException {
		// TODO Auto-generated method stub
		TimeZone.setDefault(TimeZone.getTimeZone("IST"));
		JSONArray summaryResponse = new JSONArray();
		JSONArray dashboardResponse;
		String uniqueColumn = (String) payload.get("summaryuniquecolumn");
		JSONObject fields = (JSONObject) payload.get("fields");
		String parseSeq = (String) payload.get("parseseq");
		JSONArray dashresp = (JSONArray) payload.get("dashResponse");
		Timestamp currentTime=new Timestamp(System.currentTimeMillis());
		String fromtime = (String) dashboardRequest.get("fromtimestamp");
		String totime = (String) dashboardRequest.get("totimestamp");
		String criteria = (String) dashboardRequest.get("criteria");
		String dashboard = (String) dashboardRequest.get("dashboard");
		String type="";
		String seq=" and "+payload.get("minParseSeq")+"<=sequence<="+parseSeq;
		String qString="";
		if(payload.get("qstring")!=null) {
			qString=" and processstate='"+payload.get("qstring").toString()+"'";
		}
		
		if (dashboardRequest.containsKey("type") && dashboardRequest.get("type").toString().trim()!=null && !(dashboardRequest.get("type").toString().equalsIgnoreCase("all"))) {
			type =" and "+fields.get("type").toString()+"='"+dashboardRequest.get("type").toString()+"'";
		}
		String partitionDate;
		String currentDate;
		if(fromtime.substring(0, 10).equals(totime.substring(0, 10))) {
			partitionDate="cast(processdate as date) = cast('"+fromtime.substring(0, 10)+"' as date)";
		}else {
			partitionDate="cast(processdate as date) between cast('"+fromtime.substring(0, 10)+"' as date) and cast('"+totime.substring(0, 10)+"' as date) ";
		}
		
		if(currentTime.toString().substring(0, 10).equals(fromtime.substring(0,10))) {
			currentDate="cast(processdate as date) = cast('"+fromtime.substring(0, 10)+"' as date)";
		}else {
			currentDate="cast(processdate as date) between cast('"+fromtime.substring(0, 10)+"' as date) and cast('"+currentTime.toString().substring(0, 10)+"' as date) ";
		}
		String time=partitionDate+" and cast(processtimestamp as timestamp) between cast('"+fromtime + "' as timestamp) and cast('" + totime+"' as timestamp) ";
		String t1 = "select "+uniqueColumn+",max(processtimestamp) as time from " + payload.get("pmctable")
				+ " where dashboard LIKE '" + dashboard
				+ "%' and "+currentDate+type+seq+" group by "+uniqueColumn;
		String t2 = "select * from " + payload.get("pmctable")
				+ " where dashboard LIKE '" + dashboard
				+ "%' and "+currentDate+type;
		String t3 ;
		String t4="select DISTINCT "+uniqueColumn+" from "+payload.get("pmctable")+" where "+time+" and sequence<="+parseSeq+type;
		String t5;
		String keyStr = (String) criteria;
		if (fields.containsKey(criteria)) {
			keyStr = fields.get(criteria).toString();
		}

//		if (keyStr.equals("channel") && dashboard.equals("recharge")) {
//			t3 = "select distinct "+uniqueColumn+", " + keyStr + ",processtimestamp from " + payload.get("pmctable")
//					+ " where dashboard LIKE '" + dashboard
//					+ "%' and "+currentDate+" and sequence=1";
//			t5 = "select "+uniqueColumn+",max(processtimestamp) as time from " + payload.get("pmctable")
//			+ " where "+currentDate + " and sequence=1 group by "+uniqueColumn;
//		} else {
			t3 = "select distinct "+uniqueColumn+", " + keyStr + ",processtimestamp from " + payload.get("pmctable")
					+ " where dashboard LIKE '" + dashboard
					+ "%' and "+currentDate+type+" and sequence<=" + parseSeq;
			t5 = "select "+uniqueColumn+",max(processtimestamp) as time from " + payload.get("pmctable")
			+ " where "+currentDate + type+" and sequence<="+parseSeq+qString+" group by "+uniqueColumn;
//		}
		String query = "select t3." + keyStr + " as criteria,t2.processstate as status, count(2) as sum from (" + t1
				+ ") t1, (" + t2 + ") t2, (" + t3
				+ ") t3, ("+t4+") t4, ("+t5+") t5 where  t1."+uniqueColumn+"=t4."+uniqueColumn+" and t1."+uniqueColumn+"=t2."+uniqueColumn+"  and t1."+uniqueColumn+"=t3."+uniqueColumn+" and t1."+uniqueColumn+"=t5."+uniqueColumn+" and t3.processtimestamp=t5.time and cast(t1.time as timestamp)=cast(t2.processtimestamp as timestamp) group by t3."
				+ keyStr + ",t2.processstate";
		System.out.println("query..."+query);
		ArrayList<String> al = new ArrayList<>(Arrays.asList("criteria", "status", "sum"));
		dashboardResponse = HiveQueryProcess.QueryProcess(query, al,fields,"summary");
		ObjectMapper mapper = new ObjectMapper();
		Summary summary = new Summary();
		List<Summary> summaryList = new ArrayList<Summary>();

		for (int i = 0; i < dashboardResponse.size(); i++) {
			try {
				summary = mapper.readValue(dashboardResponse.get(i).toString(), Summary.class);
			} catch (JsonParseException e) {
				System.out.println("exception.." + e);
			} catch (JsonMappingException e) {
				System.out.println("exception..." + e);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				System.out.println("exception....." + e);
			}
			summaryList.add(summary);
		}
		Map<String, List<Summary>> ListItems = summaryList.stream()
				.collect(Collectors.groupingBy(Summary::getCriteria));
		for (Entry<String, List<Summary>> entry : ListItems.entrySet()) {
			JSONObject jsobj = new JSONObject();
			Long total = 0L;
			for (Object x : dashresp) {
				jsobj.put(x, 0);
			}
			jsobj.put("criteria", entry.getValue().get(0).getCriteria());

			for (Summary x : entry.getValue()) {
				System.out.println("x" + x);
				jsobj.put(x.getStatus().toLowerCase(), Long.parseLong(x.getSum()));
				total = total + Long.parseLong(x.getSum());

			}
			jsobj.put("received", total);
			summaryResponse.add(jsobj);
		}
		return summaryResponse;
	}

	@Override
	public JSONArray ErrorSummaryProcess(JSONObject dashboardErrorRequest, JSONObject payload) throws NoRecordsException, FileNotExistException  {
		// TODO Auto-generated method stub
		TimeZone.setDefault(TimeZone.getTimeZone("IST"));
		JSONArray dashboardErrorResponse;
		String uniqueColumn = (String) payload.get("summaryuniquecolumn");
		JSONObject fields=(JSONObject) payload.get("fields");
		Timestamp currentTime=new Timestamp(System.currentTimeMillis());
		String fromtime = (String) dashboardErrorRequest.get("fromtimestamp");
		String totime = (String) dashboardErrorRequest.get("totimestamp");
		String dashboard = (String) dashboardErrorRequest.get("dashboard");
		String parseSeq = (String) payload.get("parseseq");
		String partitionDate;
		String currentDate;
		String type="";
		
		if (dashboardErrorRequest.containsKey("type") && dashboardErrorRequest.get("type").toString().trim()!=null && !(dashboardErrorRequest.get("type").toString().equalsIgnoreCase("all"))) {
			type =" and "+fields.get("type").toString()+"='"+dashboardErrorRequest.get("type").toString()+"'";
		}
		
		if(fromtime.substring(0, 10).equals(totime.substring(0, 10))) {
			partitionDate="cast(processdate as date) = cast('"+fromtime.substring(0, 10)+"' as date)";
		}else {
			partitionDate="cast(processdate as date) between cast('"+fromtime.substring(0, 10)+"' as date) and cast('"+totime.substring(0, 10)+"' as date) ";
		}
		
		if(currentTime.toString().substring(0, 10).equals(fromtime.substring(0,10))) {
			currentDate="cast(processdate as date) = cast('"+fromtime.substring(0, 10)+"' as date)";
		}else {
			currentDate="cast(processdate as date) between cast('"+fromtime.substring(0, 10)+"' as date) and cast('"+currentTime.toString().substring(0, 10)+"' as date) ";
		}
		String time=partitionDate+" and cast(processtimestamp as timestamp) between cast('"+fromtime + "' as timestamp) and cast('" + totime+"' as timestamp) ";

		String t1 = "select "+uniqueColumn+",max(processtimestamp) as time from " + payload.get("pmctable")
				+ " where dashboard LIKE '" + dashboard
				+ "%' and "+currentDate+type+" group by "+uniqueColumn;
		String t2 = "select distinct "+uniqueColumn+", errorcode, eventtype, processtimestamp,receivedtimestamp from "
				+ payload.get("pmctable") + " where dashboard LIKE '" + dashboard
				+ "%' and  "+currentDate+type+" and processstate='FAILED'";
		String t3="select DISTINCT "+uniqueColumn+" from "+payload.get("pmctable")+" where "+time+type+" and sequence<="+parseSeq;

		String query = "select t2.eventtype as activityname, t2.errorcode as errorcode, count(2) as total from (" + t1
				+ ") t1, (" + t2
				+ ") t2, ("+t3+") t3 where t1."+uniqueColumn+"=t2."+uniqueColumn+" and t1."+uniqueColumn+"=t3."+uniqueColumn+" and t1.time=t2.processtimestamp group by t2.eventtype, t2.errorcode";

		ArrayList<String> al = (ArrayList<String>) payload.get("dashErrorResponse");
		dashboardErrorResponse = HiveQueryProcess.QueryProcess(query, al,fields,"errorsummary");
		return dashboardErrorResponse;
	}

	@SuppressWarnings("unlikely-arg-type")
	@Override
	public JSONObject ProcessDetailsProcess(JSONObject processDetailsRequest, JSONObject payload) throws NoRecordsException   {
		// TODO Auto-generated method stub
		JSONObject response = new JSONObject();
		TimeZone.setDefault(TimeZone.getTimeZone("IST"));
		Timestamp currentTime=new Timestamp(System.currentTimeMillis());
		String tid = ((String) processDetailsRequest.get("referenceno")).trim();
		String dashboard = (String) processDetailsRequest.get("dashboard");
		String transactionTimestamp = (String) processDetailsRequest.get("transDate");
		
		JSONObject fields = (JSONObject) payload.get("fields");
		ArrayList<String> statusArr=new ArrayList<String>();
		ArrayList<String> Lineitemseq = (ArrayList<String>) payload.get("lineitemseq");
		ArrayList<String> rechargeMandatoryseq = (ArrayList<String>) payload.get("mandatoryseq");
		Integer rechargeLastseq =  Integer.valueOf((String) payload.get("lastseq"));
		String uniqueColumn = (String) payload.get("uniquecolumn");
		String currentDate;
		if(transactionTimestamp==null || transactionTimestamp.length()<10 || currentTime.toString().substring(0, 10).equals(transactionTimestamp.substring(0,10))) {
			currentDate="cast(processdate as date) = cast('"+currentTime.toString().substring(0, 10)+"' as date)";
		}else {
			if(!(transactionTimestamp.contains("-"))) {
				transactionTimestamp=transactionTimestamp.substring(0, 4)+"-"+transactionTimestamp.substring(4, 6)+"-"+transactionTimestamp.substring(6, 8);
			}
			currentDate="cast(processdate as date) between cast('"+transactionTimestamp.substring(0, 10)+"' as date) and cast('"+currentTime.toString().substring(0, 10)+"' as date) ";
		}
		
		
		if(payload.get("milestoneStyle").toString().equals("normal")) {
		
		String transrefno = "";
		
		
		
		
		if(processDetailsRequest.get("transrefno").toString().trim()==null || processDetailsRequest.get("transrefno").toString().trim().equals("")) {
			if(dashboard.equalsIgnoreCase("recharge")) {
			transrefno=" and str1='1'";
			}
		}else {
			transrefno = " and str1='"+processDetailsRequest.get("transrefno").toString().trim()+"'";
		}
		
		
		ArrayList<String> Mandatoryseq;
		
		Integer selfLastseq=null;
		ArrayList<String> selfLineitemseq=null;
		ArrayList<String> selfMandatoryseq=null;
		if(payload.get("selflineitemseq")!=null) {
		 selfLineitemseq = (ArrayList<String>) payload.get("selflineitemseq");
		}
		if(payload.get("selfmandatoryseq")!=null) {
		 selfMandatoryseq = (ArrayList<String>) payload.get("selfmandatoryseq");
		}
		if(payload.get("selflastseq")!=null) {
		selfLastseq = Integer.valueOf((String) payload.get("selflastseq"));
		}
		Integer Lastseq;
		String finalState=null;
		
		String t1 = "select eventtype, max(processtimestamp) as processedtimestamp from "
				+ payload.get("pmctable") + " where dashboard LIKE '" + dashboard + "%' and referenceno='" + tid
				+ "' "+transrefno+" and "+currentDate+" group by eventtype";
		String t2 = "select * from " + payload.get("pmctable") + " where dashboard LIKE '" + dashboard
				+ "%' and referenceno='" + tid + "' "+transrefno+" and "+currentDate;
		String query = "select t2.receivedpayload as payload, t2.dashboard as dashboard, t2.eventtype as processname, t2.receivedtimestamp as activitytimestamp,t2.processstate as activitystate, t2.errorcode as errorcode, t2.sequence as sequence, t2.referenceno as transactionid from ("
				+ t1 + ") t1, (" + t2
				+ ") t2 where t1.eventtype=t2.eventtype and t1.processedtimestamp=t2.processtimestamp order by sequence,activitytimestamp";
		System.out.println("queryyy.."+query);
		List<Milestone> milestone = HiveQueryProcess.QueryPayload(query);
		LineDetails listDetails = new LineDetails();
		List<LineDetails> lineItemdetails = new ArrayList<LineDetails>();
		List<Details> itemDetails = new ArrayList<Details>();
		if(fields.get(milestone.get(0).getDashboard())!=null) {
		listDetails.setProcesstype(fields.get(milestone.get(0).getDashboard()).toString().toUpperCase());
		}else {
			listDetails.setProcesstype(milestone.get(0).getDashboard().toUpperCase());	
		}
		listDetails.setProcessname(tid);
		if(milestone.get(0).getDashboard().equalsIgnoreCase(dashboard)) {
			Lastseq=rechargeLastseq;
			Mandatoryseq=rechargeMandatoryseq;
		}else {
			
			if(milestone.get(0).getDashboard().equalsIgnoreCase("rechargevoucher") && milestone.get(0).getPayload().contains("BVV")) {
			Mandatoryseq=rechargeMandatoryseq;
			Lastseq=rechargeLastseq;
			}else {
				Mandatoryseq=selfMandatoryseq;	
				Lastseq=selfLastseq;
				Lineitemseq=selfLineitemseq;
			}
		}
		for(int j=0;j<milestone.size();j++){
			Milestone current=milestone.get(j);
			Details item = new Details();
			item.setProcessname(current.getProcessName());
			if(current.getSequence()==6 && current.getActivityState().equals("CANCELLED")) {
			item.setActivitystate("COMPLETED");
			}else {
				item.setActivitystate(current.getActivityState());	
			}
			item.setActivitytimestamp(current.getActivityTimestamp());
			item.setErrorcode(current.getErrorCode());
			 if (Lineitemseq.contains(current.getSequence().toString())) {
				statusArr.add(current.getActivityState().toUpperCase());
				itemDetails.add(item);
			 }
				if (j == milestone.size() - 1) {
					if(current.getSequence()>=Lastseq||current.getActivityState().equalsIgnoreCase("failed")) {
						finalState=statusArr.get(statusArr.size()-1);
					}else {
						finalState="INPROGRESS";
					}
					if(statusArr.contains("FAILED")) {
						finalState="FAILED";
					}
					for (String key : Mandatoryseq) {
						if (current.getSequence() < Integer.valueOf(key)) {
							Details mandatoryItem = new Details();
							mandatoryItem.setProcessname((String) fields.get("activity"+key));
							mandatoryItem.setActivitystate("CREATED");
							mandatoryItem.setActivitytimestamp(currentTime.toString());
							System.out.println("time"+currentTime.toString());
							itemDetails.add(mandatoryItem);
						} 
					}
				}
				listDetails.setProcessstate(finalState);
				listDetails.setActivities(itemDetails);
			
			
		}
		lineItemdetails.add(listDetails);
		response.put("lineItems", lineItemdetails);
		}
		else if(payload.get("milestoneStyle").toString().equals("tree")) {
			ArrayList<String> parentitemseq = (ArrayList<String>) payload.get("parentlineseq");

			String t1 = "select eventtype,"+uniqueColumn+", max(processtimestamp) as processedtimestamp from "
					+ payload.get("pmctable") + " where dashboard LIKE '" + dashboard + "%' and referenceno='" + tid
					+ "' and "+currentDate+" group by eventtype,"+uniqueColumn;
			String t2 = "select * from " + payload.get("pmctable") + " where dashboard LIKE '" + dashboard
					+ "%' and referenceno='" + tid + "' and "+currentDate;
			String query = "select t2.receivedpayload as payload, t2.dashboard as dashboard, t2.eventtype as processname, t2.receivedtimestamp as activitytimestamp,t2.processstate as activitystate, t2.errorcode as errorcode, t2.sequence as sequence, t2."+uniqueColumn+" as transactionid from ("
					+ t1 + ") t1, (" + t2
					+ ") t2 where t1.eventtype=t2.eventtype and t1.processedtimestamp=t2.processtimestamp order by sequence";
			List<Milestone> milestone = HiveQueryProcess.QueryPayload(query);
			
			Map<String, List<Milestone>> ListItems = (Map<String, List<Milestone>>) milestone.stream().collect(Collectors.groupingBy(Milestone::getTransactionid));
			LineDetails parentDetails = new LineDetails();
			List<LineDetails> listLineDetails = new ArrayList<LineDetails>();
			List<Details> parentListDetails = new ArrayList<Details>();
			List<String> finalStatus=new ArrayList<String>();
			int i=1;
			for (Entry<String, List<Milestone>> entry : ListItems.entrySet()) {
				System.out.println(" out "+entry.getValue().get(0).getSequence().toString());
				LineDetails lineDetails=new LineDetails();
				List<String> status=new ArrayList<String>();
				List<Details> listDetails = new ArrayList<Details>();
				Integer lastSeq=null;
				String lastStatus=null;
					lineDetails.setProcessname("LINEITEM_"+tid+"_"+i);
					lineDetails.setProcesstype("LineItem");
				
				for(Milestone record:entry.getValue()) {
					System.out.println("inner"+record.getSequence()+record.getProcessName());
					Details details=new Details();
					details.setProcessname(record.getProcessName());
					details.setActivitystate(record.getActivityState());
					details.setActivitytimestamp(record.getActivityTimestamp());
					details.setErrorcode(record.getErrorCode());
					status.add(record.getActivityState().toUpperCase());
					lastSeq=record.getSequence();
					lastStatus=record.getActivityState();
					if(Lineitemseq.contains(record.getSequence().toString())) {
						System.out.println("added in lineitem");
						listDetails.add(details);
					}else if(parentitemseq.contains(record.getSequence().toString())) {
						parentListDetails.add(details);
						System.out.println("added in parent");
					}
					
				}
				
					lineDetails.setActivities(listDetails);
					if(status.contains("FAILED")) {
						lineDetails.setProcessstate("FAILED");
						finalStatus.add("FAILED");
					}else if(rechargeLastseq<=lastSeq) {
						lineDetails.setProcessstate(lastStatus);
						finalStatus.add(lastStatus);
					}else {
						lineDetails.setProcessstate("INPROGRESS");
						finalStatus.add("INPROGRESS");
						for (String key : rechargeMandatoryseq) {
							if (lastSeq < Integer.valueOf(key)) {
																
								Details manDetails=new Details();
								manDetails.setProcessname((String) fields.get("activity"+key));
								manDetails.setActivitystate("CREATED");
								manDetails.setActivitytimestamp(currentTime.toString());
								listDetails.add(manDetails);
								
							} 
						}
					}
					listLineDetails.add(lineDetails);
				
				i++;
				
			}

			parentDetails.setActivities(parentListDetails);
			parentDetails.setProcessname(tid);
			parentDetails.setProcesstype(dashboard);
			if(finalStatus.contains("FAILED")) {
				parentDetails.setProcessstate("FAILED");
			}else if(finalStatus.contains("INPROGRESS")) {
				parentDetails.setProcessstate("INPROGRESS");
			}else {
				parentDetails.setProcessstate("COMPLETED");
			}
			response.put("parentNode", parentDetails);
			response.put("lineItems", listLineDetails);
			
		}
		
		return response;
	}

	@Override
	public JSONArray ErrorTrackingProcess(JSONObject errorTrackingRequest, JSONObject payload) throws NoRecordsException, FileNotExistException  {
		// TODO Auto-generated method stub

		JSONArray errorTrackingResponse;
		JSONObject fields = (JSONObject) payload.get("fields");
		String uniqueColumn = (String) payload.get("uniquecolumn");
		String fromtime = (String) errorTrackingRequest.get("fromtimestamp");
		String totime = (String) errorTrackingRequest.get("totimestamp");
		String dashboard = (String) errorTrackingRequest.get("dashboard");
		String parseSeq = (String) payload.get("parseseq");
		String filetrParams = "";
		Integer limit = 50;
		TimeZone.setDefault(TimeZone.getTimeZone("IST"));
		Timestamp currentTime=new Timestamp(System.currentTimeMillis());
		ArrayList<String> al = (ArrayList<String>) payload.get("errorTrackingResponse");
		String qString="";
		if(payload.get("qstring")!=null) {
			qString=" and processstate='"+payload.get("qstring").toString()+"'";
		}
		if (errorTrackingRequest.get("activityname") != null
				&& !(errorTrackingRequest.get("activityname")).toString().isEmpty()) {
			if(fields.containsKey(errorTrackingRequest.get("activityname"))) {
			filetrParams = filetrParams + " and eventtype='" + fields.get(errorTrackingRequest.get("activityname")) + "'";
			}else {
				filetrParams = filetrParams + " and eventtype='" + errorTrackingRequest.get("activityname") + "'";

			}
		}
		if (errorTrackingRequest.get("errorcode") != null
				&& !(errorTrackingRequest.get("errorcode").toString().isEmpty())) {
			filetrParams = filetrParams + " and errorcode='" + errorTrackingRequest.get("errorcode") + "'";
		}
		if (errorTrackingRequest.get("numberofrows") != null
				&& (Integer.valueOf((String) errorTrackingRequest.get("numberofrows")) > 0)) {
			limit = Integer.valueOf((String) errorTrackingRequest.get("numberofrows"));
		}
		
		String type="";
		if (errorTrackingRequest.containsKey("type") && errorTrackingRequest.get("type").toString().trim()!=null && !(errorTrackingRequest.get("type").toString().equalsIgnoreCase("all"))) {
			type =" and "+fields.get("type").toString()+"='"+errorTrackingRequest.get("type").toString()+"'";
		}
		String partitionDate;
		String currentDate;
		if(fromtime.substring(0, 10).equals(totime.substring(0, 10))) {
			partitionDate="cast(processdate as date) = cast('"+fromtime.substring(0, 10)+"' as date)";
		}else {
			partitionDate="cast(processdate as date) between cast('"+fromtime.substring(0, 10)+"' as date) and cast('"+totime.substring(0, 10)+"' as date) ";
		}
		
		if(currentTime.toString().substring(0, 10).equals(fromtime.substring(0,10))) {
			currentDate="cast(processdate as date) = cast('"+fromtime.substring(0, 10)+"' as date)";
		}else {
			currentDate="cast(processdate as date) between cast('"+fromtime.substring(0, 10)+"' as date) and cast('"+currentTime.toString().substring(0, 10)+"' as date) ";
		}
		String time=partitionDate+" and cast(processtimestamp as timestamp) between cast('"+fromtime + "' as timestamp) and cast('" + totime+"' as timestamp) ";
		String t1 = "select "+uniqueColumn+",max(processtimestamp) as time from " + payload.get("pmctable")
				+ " where dashboard like '" + dashboard
				+ "%' and "+currentDate+type+" group by "+uniqueColumn;

		String t2 = "select * from " + payload.get("pmctable") + " where dashboard like '" + dashboard
				+ "%' and  "+currentDate+" and processstate='FAILED' " + filetrParams+type;
		String transTime="";
		StringBuilder select = new StringBuilder();
		for (String key : al) {
			String keyStr = key;
			
			if (fields.containsKey(key)) {
				keyStr = fields.get(key).toString();
			}
			
			if(key.equalsIgnoreCase("transactiontimestamp")) {
				transTime=","+keyStr;
				select.append(", t3." + keyStr + " as " + key);
			}else {
			select.append(", t2." + keyStr + " as " + key);
			}

		}
		String t3="select DISTINCT "+uniqueColumn+transTime+" from "+payload.get("pmctable")+" where "+time+type+" and sequence<="+parseSeq+qString;

		String query = "select " + select.toString().substring(1) + " from (" + t1 + ") t1, (" + t2
				+ ") t2, ("+t3+") t3 where t1."+uniqueColumn+"=t3."+uniqueColumn+" and t1."+uniqueColumn+"=t2."+uniqueColumn+" and t1.time=t2.processtimestamp order by processtimestamp desc LIMIT " + limit;
		System.out.println("query  "+query);

		errorTrackingResponse = HiveQueryProcess.QueryProcess(query, al,fields,"errortracking");
		return errorTrackingResponse;
	}

	@Override
	public JSONArray trackingLineItemsProcess(JSONObject trackingLineItemsRequest, JSONObject payload) throws NoRecordsException, FileNotExistException
			 {
		// TODO Auto-generated method stub

		JSONArray trackingLineItemsResponse;
		JSONObject fields = (JSONObject) payload.get("fields");
		String uniqueColumn = (String) payload.get("uniquecolumn");
		String parseSeq = (String) payload.get("parseseq");
		String dashboard = (String) trackingLineItemsRequest.get("dashboard");
		String transactionid = (String) trackingLineItemsRequest.get("referenceno");
		String transrefno = (String) trackingLineItemsRequest.get("transrefno");
		String transactionTimestamp = (String) trackingLineItemsRequest.get("transactiontimestamp");
		TimeZone.setDefault(TimeZone.getTimeZone("IST"));
		Timestamp currentTime=new Timestamp(System.currentTimeMillis());
		String seq=" and "+payload.get("minParseSeq")+"<=sequence<="+parseSeq;
		String currentDate;
		String qString="";
		if(payload.get("qstring")!=null) {
			qString=" and processstate='"+payload.get("qstring").toString()+"'";
		}
		if(transactionTimestamp==null || transactionTimestamp.length()<10 || currentTime.toString().substring(0, 10).equals(transactionTimestamp.substring(0,10))) {
			currentDate="cast(processdate as date) = cast('"+currentTime.toString().substring(0, 10)+"' as date)";
		}else {
			currentDate="cast(processdate as date) between cast('"+transactionTimestamp.substring(0, 10)+"' as date) and cast('"+currentTime.toString().substring(0, 10)+"' as date) ";
		}
		String transSelect="";
		if(transrefno!=null && !(transrefno.equals(""))) {
			transSelect=" and str1='"+transrefno+"'";
		}
		
		
		String t1 = "select "+uniqueColumn+",max(processtimestamp) as time from " + payload.get("pmctable")
				+ " where dashboard LIKE '" + dashboard + "%' and referenceno='" + transactionid
				+ "'"+transSelect+" and "+currentDate+seq+" group by "+uniqueColumn;
		String t2 = "select * from " + payload.get("pmctable")
				+ " where dashboard LIKE '" + dashboard + "%' and referenceno='" + transactionid + "'"+transSelect+" and "+currentDate;

		String t3 = "select * from " + payload.get("pmctable") + " where dashboard LIKE '" + dashboard
				+ "%' and referenceno='" + transactionid + "' and sequence<=" + parseSeq+transSelect+" and "+currentDate;
		String t4 = "select "+uniqueColumn+",max(processtimestamp) as time from " + payload.get("pmctable")
		+ " where dashboard LIKE '" + dashboard + "%' and referenceno='" + transactionid
		+ "'"+transSelect+" and sequence<="+parseSeq+qString+" and "+currentDate+" group by "+uniqueColumn;
		ArrayList<String> al = (ArrayList<String>) payload.get("trackingLineItemsResponse");
		StringBuilder select = new StringBuilder();
		for (String key : al) {
			String keyStr = key;
			if (fields.containsKey(key)) {
				keyStr = fields.get(key).toString();
			}
			switch (key) {
			case "processstate":
				select.append(", t2." + keyStr + " as " + key);
				break;
			case "processtimestamp":
				select.append(", t2." + keyStr + " as " + key);
				break;
			
			default:
				select.append(", t3." + keyStr + " as " + key);
			}
		}
		String query = "select " + select.toString().substring(1) + " from (" + t1 + ") t1, (" + t2 + ") t2 , (" + t3
				+ ") t3,("+t4+") t4 where t1."+uniqueColumn+"=t2."+uniqueColumn+" and t1.time=t2.processtimestamp and t1."+uniqueColumn+"=t3."+uniqueColumn+" and t4.time=t3.processtimestamp";
		trackingLineItemsResponse = HiveQueryProcess.QueryProcess(query, al,fields,"lineitemtracking");
		return trackingLineItemsResponse;

	}

	@Override
	public JSONArray repushProcess(JSONObject repushRequest, JSONObject payload,JSONObject repsuhPayload, JSONObject solaceConfig) {
		// TODO Auto-generated method stub

		JSONArray repushResponse = new JSONArray();
		JSONObject field = (JSONObject) payload.get("fields");
		ArrayList<String> tpaChannels=null;
		if(payload.get("tpachannels")!=null) {
		tpaChannels = (ArrayList<String>) payload.get("tpachannels");
		}
		Long repushTime=null;
		if(payload.get("repushperiod")!=null) {
		repushTime= Long.valueOf(payload.get("repushperiod").toString());
		}
		
		String dashboard = (String) repushRequest.get("dashboard");
		String username = (String) repushRequest.get("username");
		TimeZone.setDefault(TimeZone.getTimeZone("IST"));
		Long milliSec=System.currentTimeMillis();
		Timestamp currentTime=new Timestamp(milliSec);
		System.out.println("request.."+repushRequest+"  repushed by "+username+" at time "+currentTime+"  "+currentTime.toString().substring(0, 10));
		HiveQueryProcess.repushAudit("insert into "+payload.get("audittable")+" partition (processdate='"+currentTime.toString().substring(0, 10)+"') values ('"+repushRequest+"','"+currentTime+"','"+username+"')");
		ArrayList<LinkedHashMap<String, String>> requests =  (ArrayList<LinkedHashMap<String, String>>) repushRequest.get("requests");
		ArrayList<JSONObject> fields = (ArrayList<JSONObject>) repsuhPayload.get("repush");
		
		for (Object request : requests) {
				JSONObject solaceConDetails = new JSONObject();
				JSONObject jmsConDetails = new JSONObject();
				JSONObject repushStatus = new JSONObject();
				LinkedHashMap<String, String> repushObject = (LinkedHashMap<String, String>) request;
				String eventtype = (String) repushObject.get("interfaceid");
				if(eventtype.equals("RechargeAccount")) {
					eventtype="RefillManagement";
				}
				String rechargerefno = (String) repushObject.get("referenceno");
				String timestamp = (String) repushObject.get("processtimestamp");
				String transrefno = (String) repushObject.get("transrefno");
				if(transrefno==null || transrefno.equals("")) {
					transrefno="1";
				}
				try {
					repushStatus.put(rechargerefno, "SUCCESS");

				
				
				
				String query = "select str2 as jioroute, channel,dashboard,receivedpayload,interfaceid from  "
							+ payload.get("pmctable") + " where dashboard LIKE '" + dashboard + "%' and referenceno='"
							+ rechargerefno + "' and eventtype LIKE '" +eventtype
							+ "%' and (cast(receivedtimestamp as timestamp)=cast('"
							+ timestamp + "' as timestamp) or cast(processtimestamp as timestamp)=cast('"+ timestamp +"' as timestamp)) and str1='"+transrefno+"' and processdate='"+timestamp.substring(0, 10)+"' and processstate='FAILED'";
				
				ArrayList<String> al = new ArrayList<>(Arrays.asList("receivedpayload","dashboard","channel","interfaceid","jioroute"));
				
				
				System.out.println("repush query.."+query);
				JSONArray response = HiveQueryProcess.QueryProcess(query, al,field,"repush");
				JSONObject hiveResp = (JSONObject) response.get(0);
				
				if(tpaChannels.contains(hiveResp.get("channel"))) {
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
				ArrayList<String> transdate=new ArrayList<String>();
				ArrayList<String> transTimestamp=jsonParser.parse(hiveResp.get("receivedpayload").toString(), "transDateTime", transdate);
				java.util.Date parsedDate=dateFormat.parse(timestamp);
				if(!(transTimestamp.isEmpty())) {
				 dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
				 parsedDate = dateFormat.parse(transTimestamp.get(0));
				}
				Timestamp timestamp1 = new Timestamp(parsedDate.getTime());
				if(repushTime<(currentTime.getTime()-timestamp1.getTime())) {
					System.out.println("this repush is restricted current time"+currentTime+" trans time"+timestamp1);
					throw new CustomAppException("this repush is restricted");
				}
				}
				JSONObject details = new JSONObject();
				for (Object key : fields) {

					JSONObject keyStr = (JSONObject) key;
					System.out.println("key"+keyStr+"   "+hiveResp.get("interfaceid").toString()+"_"+eventtype.split("_")[0]+"_"+hiveResp.get("dashboard").toString());
					if (keyStr.get(hiveResp.get("interfaceid").toString()+"_"+eventtype.split("_")[0]+"_"+hiveResp.get("dashboard").toString())!=null) {
						details = (JSONObject) keyStr.get(hiveResp.get("interfaceid").toString()+"_"+eventtype.split("_")[0]+"_"+hiveResp.get("dashboard").toString());
						break;
					}
				}
				
				if (details.size() == 0) {
					System.out.println("repush configuration is not available.... ");
					throw new CustomAppException("repush configuration is not available.... ");
				}
				
				if (details.get("type").toString().equals("solace")) {
					ArrayList<JSONObject> solaceDetails = (ArrayList<JSONObject>) solaceConfig.get("solace");

					String solaceCon=(String) details.get("solacecon");

				for (Object configs : solaceDetails) {
					JSONObject keyStr = (JSONObject) configs;
					if (keyStr.get(solaceCon)!=null) {
						solaceConDetails = (JSONObject) keyStr.get(solaceCon);
						break;
					}
				}
				solacePublisher.createCon(solaceConDetails);
				

					solacePublisher.publishMessage(eventtype,rechargerefno,transrefno,hiveResp.get("receivedpayload").toString(),
							(String) details.get("queue"),hiveResp.get("jioroute").toString());

				}else if (details.get("type").toString().equals("jms")) {
					String jmsCon=(String) details.get("jmscon");
					ArrayList<JSONObject> jmsDetails = (ArrayList<JSONObject>) solaceConfig.get("jms");
					for (Object configs : jmsDetails) {
						JSONObject keyStr = (JSONObject) configs;
						if (keyStr.get(jmsCon)!=null) {
							jmsConDetails = (JSONObject) keyStr.get(jmsCon);
							break;
						}
					}
					jmsPublisher.publishMessage(jmsConDetails,hiveResp.get("receivedpayload").toString(),details.get("queue").toString());
				
				}
				
				else {
					restCall.restPublisher((JSONObject) hiveResp.get("receivedpayload"),
							(String) details.get("url"));
				}
				
			} catch (Exception e) {
				System.out.println("exception "+e.getStackTrace()+e.toString());
				
				repushStatus.put(rechargerefno, "FAILED");
			}
				
				repushResponse.add(repushStatus);
		}
		return repushResponse;
	}

	@Override
	public JSONObject payloadProcess(JSONObject payloadRequest, JSONObject payload) throws NoRecordsException, FileNotExistException  {
		// TODO Auto-generated method stub

		JSONArray queryResponse;
		JSONObject payloadResponse = new JSONObject();
		JSONObject fields = (JSONObject) payload.get("fields");
		String eventtype = (String) payloadRequest.get("interfaceid");
		if(eventtype.equals("RechargeAccount")) {
			eventtype="RefillManagement";
		}
		String rechargerefno = (String) payloadRequest.get("referenceno");
		String dashboard = (String) payloadRequest.get("dashboard");
		String status = (String) payloadRequest.get("status");
		String timestamp = (String) payloadRequest.get("processtimestamp");
		String query;
		String state;
		
		if(status.equals("COMPLETED")) {
			state="('INPROGRESS','COMPLETED')";
		}else {
			state="('"+status+"')";
		}
		
			query = "select stacktrace,errorcode,processedlogmessage,receivedlogmessage,receivedpayload,processedpayload from "
					+ payload.get("pmctable") + " where dashboard LIKE '" + dashboard + "%' and referenceno='"
					+ rechargerefno + "' and eventtype='" + eventtype + "' and processstate in " + state
					+ " and cast(receivedtimestamp as timestamp)=cast('" + timestamp
					+ "' as timestamp) and processdate='"+timestamp.substring(0, 10)+"'";
		
		ArrayList<String> al = new ArrayList<>(Arrays.asList("errorcode", "stacktrace", "processedlogmessage",
				"receivedlogmessage", "receivedpayload", "processedpayload", "processedtimestamp"));
		
		System.out.println("query  "+query);
		queryResponse = HiveQueryProcess.QueryProcess(query, al,fields,"payload");
		JSONObject response = (JSONObject) queryResponse.get(0);

		payloadResponse.put("receivedlogmessage", response.get("receivedlogmessage"));
		payloadResponse.put("receivedpayload", response.get("receivedpayload"));
		payloadResponse.put("processedlogmessage", response.get("processedlogmessage"));
		payloadResponse.put("processedpayload", response.get("processedpayload"));
		payloadResponse.put("stacktrace", response.get("stacktrace"));
		payloadResponse.put("errorcode", response.get("errorcode"));

		return payloadResponse;
	}

}
