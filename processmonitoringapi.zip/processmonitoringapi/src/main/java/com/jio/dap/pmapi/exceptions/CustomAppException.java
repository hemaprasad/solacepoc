package com.jio.dap.pmapi.exceptions;

public class CustomAppException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CustomAppException(String errorMessage) {
        super(errorMessage);
    }

}
