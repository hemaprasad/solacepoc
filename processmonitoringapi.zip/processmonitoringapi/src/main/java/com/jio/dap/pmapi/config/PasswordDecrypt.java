package com.jio.dap.pmapi.config;

import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;


public class PasswordDecrypt {

	public String decryptPass(String pass) {
		StandardPBEStringEncryptor textEncryptor = new StandardPBEStringEncryptor();
		textEncryptor.setPassword("pmcdashboard");
		//String en=textEncryptor.encrypt("surendra");
		
		String dec=textEncryptor.decrypt(pass);
		
		return dec;
	}
}
