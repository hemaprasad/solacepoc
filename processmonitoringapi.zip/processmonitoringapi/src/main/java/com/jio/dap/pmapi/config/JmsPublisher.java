package com.jio.dap.pmapi.config;

import java.util.Hashtable;

import javax.jms.JMSException;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.json.simple.JSONObject;

import com.jio.dap.pmapi.exceptions.CustomAppException;

public class JmsPublisher {

	 QueueSender qsender;  
     QueueSession qsession;  
     QueueConnection qcon;

	@SuppressWarnings("unchecked")
	public void publishMessage(JSONObject jmsDetails, String payload, String destination) throws CustomAppException {
		PasswordDecrypt passwordDecrypt = new PasswordDecrypt();
		
		@SuppressWarnings("rawtypes")
		Hashtable env = new Hashtable();  
        env.put(Context.INITIAL_CONTEXT_FACTORY, jmsDetails.get("contextfactory").toString());  
        env.put(Context.PROVIDER_URL, jmsDetails.get("url").toString());
        env.put(Context.SECURITY_PRINCIPAL, jmsDetails.get("user").toString());
        env.put(Context.SECURITY_CREDENTIALS, passwordDecrypt.decryptPass(jmsDetails.get("pass").toString()));
        
        
        InitialContext ctx;
		try {
			ctx = new InitialContext(env);
			
			
			QueueConnectionFactory qconFactory = (QueueConnectionFactory) ctx.lookup(jmsDetails.get("confactory").toString());  
		       
			qcon = qconFactory.createQueueConnection(jmsDetails.get("user").toString(),passwordDecrypt.decryptPass(jmsDetails.get("pass").toString()));
			qsession = qcon.createQueueSession(false, javax.jms.Session.AUTO_ACKNOWLEDGE);
			Queue queue=null;
			try{
	        	 queue = (Queue) ctx.lookup(destination);  
	        }
	        catch (Exception e) {
	        	queue = qsession.createQueue(destination);
	        }
	        TextMessage msg = qsession.createTextMessage();  
	        msg.setText(payload);
	        qsender = qsession.createSender(queue);  
	        qsender.send(msg);  
	        System.out.println("payload.." + payload.toString());
	        
	        qsession.close();
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
        
		 catch (JMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
          
		
		

	}

	
}
