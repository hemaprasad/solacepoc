package com.jio.dap.pmapi.exceptions;

public class FileNotExistException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public FileNotExistException(String errorMessage) {
        super(errorMessage);
    }

}
