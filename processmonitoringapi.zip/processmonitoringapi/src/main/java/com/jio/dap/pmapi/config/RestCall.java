package com.jio.dap.pmapi.config;

import org.json.simple.JSONObject;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
@Component
public class RestCall {
	
	public JSONObject restPublisher(JSONObject json, String url) {
		ResponseEntity<JSONObject> request;
//		try {
			
			RestTemplate template = new RestTemplate();
			HttpEntity<JSONObject> entity = new HttpEntity<JSONObject>(json);
			request = template.exchange(url, HttpMethod.POST, entity, JSONObject.class);
			System.out.println("response main" + request.getBody());
			
//		} catch (Exception e) {
//			System.out.println("exception.."+e);
//		}
		return request.getBody();

	}
}
