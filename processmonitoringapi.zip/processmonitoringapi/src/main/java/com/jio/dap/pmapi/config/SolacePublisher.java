package com.jio.dap.pmapi.config;

import javax.jms.Connection;
import javax.jms.DeliveryMode;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.Session;
import org.json.simple.JSONObject;

import com.jio.dap.pmapi.exceptions.CustomAppException;
import com.solacesystems.jms.SolConnectionFactory;
import com.solacesystems.jms.SolJmsUtility;

public class SolacePublisher {

	MessageProducer messageProducer;
	Session session;
	Connection connection;

	public void createCon(JSONObject solaceDetails) throws CustomAppException {
		PasswordDecrypt passwordDecrypt = new PasswordDecrypt();

		SolConnectionFactory connectionFactory;
		try {
			connectionFactory = SolJmsUtility.createConnectionFactory();
			connectionFactory.setHost(solaceDetails.get("url").toString());
			connectionFactory.setVPN(solaceDetails.get("vpn").toString());
			connectionFactory.setUsername(solaceDetails.get("user").toString());
			connectionFactory.setPassword(passwordDecrypt.decryptPass(solaceDetails.get("pass").toString()));

			connectionFactory.setDynamicDurables(true);
			connectionFactory.setRespectTTL(false);

			connection = connectionFactory.createConnection();
			session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("exception "+e.getStackTrace());
			throw new CustomAppException("exception while creating solace connection");
		}

	}

	public void publishMessage(String interfaceid, String referenceno, String transrefno, String message,
			String destination,String jioroute) throws CustomAppException {

		Queue queue;
		try {
			queue = session.createQueue(destination);
		

		messageProducer = session.createProducer(queue);

		Message messages = session.createTextMessage(message);

		messages.setStringProperty("ReplayData", message);
		messages.setStringProperty("RefNo", referenceno);
		messages.setStringProperty("CorrelationID", transrefno);
		messages.setStringProperty("CustomData", message);
		messages.setStringProperty("EventName", interfaceid);
		messages.setStringProperty("TransRefNo", transrefno);
		messages.setStringProperty("FailedEventName", interfaceid);
		messages.setStringProperty("JioRoute", jioroute);
		messageProducer.send(queue, messages, DeliveryMode.PERSISTENT, Message.DEFAULT_PRIORITY,
				Message.DEFAULT_TIME_TO_LIVE);
		
		
		} catch (JMSException e) {
			// TODO Auto-generated catch block
			System.out.println("exception "+e.getStackTrace());
			closeCon();
			throw new CustomAppException("exception while sending message on solace");
		}
		closeCon();
	}

	public void closeCon() {
		try {
			messageProducer.close();
			session.close();
			connection.close();
		} catch (JMSException e) {
			System.out.println("exception "+e.getStackTrace());
		}

	}
}
