package com.jio.dap.pmapi.config;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class JsonLoader implements InitializingBean {
	@Value("${jsonfilepath}")
	private String filepath;
	
	@Value("${repushfilepath}")
	private String repushfilepath;

	@Value("${channelsfilepath}")
	private String channelspath;

	@Value("${paymentmodefilepath}")
	private String paymentmodespath;

	JSONObject jsonObject;
	JSONObject channelsObject;
	JSONObject paymentObject;
	JSONObject repushObject;

	public JSONObject getChannels() throws IOException {

		return channelsObject;
	}

	public JSONObject getPaymentModes() throws IOException {

		return paymentObject;
	}

	public JSONObject getObject(String dashboard) throws IOException {

		JSONObject response = (JSONObject) jsonObject.get(dashboard);

		return response;
	}
	
	public JSONObject getRepushObject(String dashboard) throws IOException {

		JSONObject response = (JSONObject) repushObject.get(dashboard);

		return response;
	}

	public JSONObject objectLoad(InputStream inStream) throws IOException, ParseException {
		JSONParser parser = new JSONParser();
		StringBuilder stringBuilder = new StringBuilder();
		try (BufferedReader br = new BufferedReader(new InputStreamReader(inStream))) {
			String lines;
			while ((lines = br.readLine()) != null) {
				stringBuilder.append(lines).append("\n");
			}
		}
		String data = stringBuilder.toString();

		return (JSONObject) parser.parse(data);

	}

	@Override
	public void afterPropertiesSet() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("file" + filepath + "  " + channelspath);
		InputStream inputStream = new FileInputStream(filepath);

		jsonObject = objectLoad(inputStream);

		InputStream channelStream = new FileInputStream(channelspath);

		channelsObject = objectLoad(channelStream);

		InputStream paymentStream = new FileInputStream(paymentmodespath);
		
		paymentObject = objectLoad(paymentStream);
		
		InputStream respushStream = new FileInputStream(repushfilepath);
		
		repushObject = objectLoad(respushStream);

	}

}
