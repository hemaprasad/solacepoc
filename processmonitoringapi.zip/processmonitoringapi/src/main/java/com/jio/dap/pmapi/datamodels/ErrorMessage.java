package com.jio.dap.pmapi.datamodels;

public class ErrorMessage{

private int reasonCode;
private String errorMessage;

public String getErrorMessage() {
	return errorMessage;
}
public void setErrorMessage(String errorMessage) {
	this.errorMessage = errorMessage;
}
public int getReasonCode() {
	return reasonCode;
}
public void setReasonCode(int reasonCode) {
	this.reasonCode = reasonCode;
}
}
