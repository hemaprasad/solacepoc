package com.jio.dap.pmapi.datamodels;

public class Milestone {
	private String processName;
	private String ActivityTimestamp;
	private String ActivityState;
	private String errorCode;
	private Integer sequence;
	private String transactionid;
	private String processType;
	private String dashboard;
	private String payload;
	public String getProcessName() {
		return processName;
	}
	public void setProcessName(String processName) {
		this.processName = processName;
	}
	public String getActivityTimestamp() {
		return ActivityTimestamp;
	}
	public void setActivityTimestamp(String activityTimestamp) {
		ActivityTimestamp = activityTimestamp;
	}
	public String getActivityState() {
		return ActivityState;
	}
	public void setActivityState(String activityState) {
		ActivityState = activityState;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public Integer getSequence() {
		return sequence;
	}
	public void setSequence(Integer sequence) {
		this.sequence = sequence;
	}
	
	public String getTransactionid() {
		return transactionid;
	}
	public void setTransactionid(String transactionid) {
		this.transactionid = transactionid;
	}
	public String getProcessType() {
		return processType;
	}
	public void setProcessType(String processType) {
		this.processType = processType;
	}

	
	public String getDashboard() {
		return dashboard;
	}
	public void setDashboard(String dashboard) {
		this.dashboard = dashboard;
	}
	public String getPayload() {
		return payload;
	}
	public void setPayload(String payload) {
		this.payload = payload;
	}

}
