
package com.jio.dap.pmapi;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.jio.dap.pmapi.datamodels.ErrorMessage;

@ControllerAdvice
public class ControllerErrorHandler extends ResponseEntityExceptionHandler{
	
	@ExceptionHandler(Exception.class)
	public ResponseEntity<ErrorMessage>  handleError(Exception e){
		ErrorMessage errorMessage=new ErrorMessage();
		errorMessage.setReasonCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
		
		System.out.println("stacktrace..."+e+e.getStackTrace());
		errorMessage.setErrorMessage(e.getMessage());
		return new ResponseEntity<ErrorMessage>(errorMessage, HttpStatus.INTERNAL_SERVER_ERROR);
		
	}

}
