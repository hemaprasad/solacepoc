package com.jio.dap.pmapi.dataaccess;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.stereotype.Service;

import com.jio.dap.pmapi.exceptions.FileNotExistException;
import com.jio.dap.pmapi.exceptions.NoRecordsException;



@Service
public interface ProcessMonitoringInterface {
	
	public JSONArray SummaryProcess(JSONObject dashboardRequest, JSONObject payload) throws NoRecordsException, FileNotExistException;
	public JSONArray ErrorSummaryProcess(JSONObject dashboardErrorRequest, JSONObject payload) throws NoRecordsException, FileNotExistException;
	public JSONArray TrackingProcess(JSONObject trackingRequest, JSONObject payload) throws NoRecordsException, FileNotExistException;
	public JSONObject ProcessDetailsProcess(JSONObject processDetailsRequest, JSONObject payload) throws NoRecordsException, FileNotExistException;
	public JSONArray ErrorTrackingProcess(JSONObject errorTrackingRequest, JSONObject payload) throws NoRecordsException, FileNotExistException;
	public JSONArray trackingLineItemsProcess(JSONObject trackingLineItemsRequest, JSONObject payload) throws NoRecordsException, FileNotExistException;
	public JSONArray repushProcess(JSONObject repushRequest, JSONObject payload,JSONObject repushPayload, JSONObject solaceConfig) throws NoRecordsException, FileNotExistException;
	public JSONObject payloadProcess(JSONObject payloadRequest, JSONObject payload) throws NoRecordsException, FileNotExistException;


	

}
