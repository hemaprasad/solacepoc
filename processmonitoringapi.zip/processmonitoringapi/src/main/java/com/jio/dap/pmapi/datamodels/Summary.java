package com.jio.dap.pmapi.datamodels;

public class Summary {
private String criteria;
private String status;
private String sum;
public String getCriteria() {
	return criteria;
}
public void setCriteria(String criteria) {
	this.criteria = criteria;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public String getSum() {
	return sum;
}
public void setSum(String sum) {
	this.sum = sum;
}
@Override
public String toString() {
	return "Summary [criteria=" + criteria + ", status=" + status + ", sum=" + sum + "]";
}

}
