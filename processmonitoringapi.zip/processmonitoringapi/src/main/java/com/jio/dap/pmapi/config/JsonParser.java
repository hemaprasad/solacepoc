package com.jio.dap.pmapi.config;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Component;


@Component
public class JsonParser implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ArrayList<String> parse(String json, String field, ArrayList<String> result)  {
	try {
	JSONObject jso = new JSONObject(json);
	Iterator<?> jo=jso.keys();
	

	 while (jo.hasNext()) {
		 
		 String keystr=(String) jo.next();
		 Object keyvalue = jso.get(keystr);
	        
	        if(!(keyvalue.equals(JSONObject.NULL)) && keystr.equals(field)) {
	        	result.add(keyvalue.toString());
	        }
	        else if (keyvalue instanceof JSONObject) {
	        	parse(keyvalue.toString(), field, result);
	    }
	        else if(keyvalue instanceof JSONArray) {
		    	parse2((JSONArray)keyvalue, field,result);
		    }
        
	 }
	}catch(Exception e) {
		System.out.println("Exception.."+e.getStackTrace());
	}
	 return result;
	 
	}
	
	public void parse2(JSONArray json2, String field, ArrayList<String> result)  {
		try {
		for (int i=0;i<json2.length();i++) {
			JSONObject jso=(JSONObject) json2.get(i);
			 parse(jso.toString(),field, result);
			
		 }

	}catch(Exception e) {
		System.out.println("Exception.."+e.getStackTrace());
	}	
	}
}
