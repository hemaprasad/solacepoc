package com.jio.dap.pmapi.config;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.dbcp.BasicDataSource;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.security.UserGroupInformation;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.jio.dap.pmapi.datamodels.Milestone;
import com.jio.dap.pmapi.exceptions.FileNotExistException;
import com.jio.dap.pmapi.exceptions.NoRecordsException;

@Service
public class HiveQueryProcess {

	@Value("${hive.url}")
    private String databaseUri;
  
    @Value("${hive.driver-class-name}")
    private String hiveDriver;

    @Value("${kerberos.user}")
    private String kerberosUser;
    
    @Value("${kerberos.keytab}")
    private String kerberosKeytab;
    
    @Value("${hadoopfilepath}")
    private String hadoopfilepath;

    JdbcTemplate hiveJdbcTemplate;
	
	@Autowired
	JsonLoader jsonLoader;
	
	public void hiveConnection(Boolean conStatus) {
		if (conStatus.equals(false)) {
			synchronized (HiveQueryProcess.class) {
				
		System.out.println("hiveconn started");
		org.apache.hadoop.conf.Configuration conf = new org.apache.hadoop.conf.Configuration();
		conf.set("hadoop.security.authentication", "Kerberos");
		conf.addResource(new Path("file://"+hadoopfilepath));
		UserGroupInformation.setConfiguration(conf);
		try {
			UserGroupInformation.loginUserFromKeytab(kerberosUser, kerberosKeytab);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("exceeee  "+e+e.getStackTrace()+e.getMessage());
		}
		
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUrl(databaseUri);
		dataSource.setDriverClassName(hiveDriver);
		
		System.out.println("hiveconn connected"+dataSource);
		hiveJdbcTemplate=new JdbcTemplate(dataSource);
				
			}
		}
		
		
      
	}

	@SuppressWarnings("unchecked")
	public JSONArray QueryProcess(String query, ArrayList<String> al, JSONObject fields, String queryType) throws NoRecordsException,FileNotExistException {
		int maxRetries=1;
		JSONObject channels;
		JSONObject paymentModes;
		try {
			channels = jsonLoader.getChannels();
			paymentModes = jsonLoader.getPaymentModes();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			System.out.println("exception "+e1.getStackTrace());
			throw new FileNotExistException("exception while loading channels and payment modes");
		}
		
		JSONArray hiveResponse = new JSONArray();
		StringBuilder filter=new StringBuilder();
		List<Map<String, Object>> rows = null;
		for(int i=0;i<=maxRetries;i++) {
		try {
			rows = hiveJdbcTemplate.queryForList(query);
		} catch (Exception e) {
			System.out.println("exception" + e);
			hiveConnection(false);
			
		}
		}
		Iterator<Map<String, Object>> it = rows.iterator();
		while (it.hasNext()) {
			Map<String, Object> db = it.next();
			JSONObject response = new JSONObject();
			if(fields.containsKey("filter") && queryType.equals("tracking") && db.get("processtype").toString().equals(fields.get("filter").toString()) && db.get("referenceno").toString().equals(db.get("transrefno").toString()) && filter.toString().contains(db.get("referenceno").toString())) {
			}
			else {
			if(fields.containsKey("filter") && queryType.equals("tracking")) {
			filter=filter.append(db.get("referenceno").toString());
			}
			
			for (String key : al) {
				
				Object keyVal = db.get(key);
				switch (key) {
				
				case "channel":
					Object channel = channels.get(keyVal);
					if (channel != null) {
						response.put(key, channel);
					} else {
						if (keyVal != null) {
							response.put(key, keyVal);
						} else {
							response.put(key, "");
						}
					}
					break;
				case "criteria":
					if (keyVal == null || keyVal.equals("")) {
						if(fields.get("UNKNOWN")!=null) {
							response.put(key, fields.get("UNKNOWN"));
						}else {
						response.put(key, "UNKNOWN");
						}
					} else {
						Object criteria = (String) channels.get(keyVal);
						if (criteria != null) {
							response.put(key, criteria);
						} else {
							response.put(key, keyVal);
						}
					}
					break;
				case "paymentmode":

					Object paymentmode = (String) paymentModes.get(keyVal);
					if (paymentmode != null) {
						response.put(key, paymentmode);
					} else {
						if (keyVal != null) {
							response.put(key, keyVal);
						} else {
							response.put(key, "");
						}
					}

					break;
				default:
					if (keyVal != null && fields.get(keyVal)==null) {
						response.put(key, keyVal.toString());
					} else if(keyVal != null && fields.get(keyVal)!=null){
						response.put(key, fields.get(keyVal));
					}
					else {
						response.put(key, "");
					}

				}
			}
				
			}
			if(!(response.isEmpty())) {
			hiveResponse.add(response);
			}
		}
		if (hiveResponse.isEmpty()) {
			throw new NoRecordsException("No Records Found");
		}
		return hiveResponse;

	}

	public List<Milestone> QueryPayload(String query) throws NoRecordsException {
		int maxRetries=1;

		
		List<Milestone> response = new ArrayList<Milestone>();
		List<Map<String, Object>> rows = null;
		for(int i=0;i<=maxRetries;i++) {
		
		try {
			rows = hiveJdbcTemplate.queryForList(query);
		} catch (Exception e) {
			System.out.println("exception" + e+e.getStackTrace());
				
			hiveConnection(false);
				
			
		}
		}
		Iterator<Map<String, Object>> it = rows.iterator();

		while (it.hasNext()) {
			Milestone ml = new Milestone();
			Map<String, Object> db = it.next();
			Object processName = db.get("processname");
			if(processName!=null) {
			Object activityState = db.get("activitystate");
			Object activityTimestamp = db.get("activitytimestamp");
			Object errorCode = db.get("errorcode");
			
			Object payload = db.get("payload");
			if(processName.toString().equals("RefillManagement")) {
				processName="RechargeAccount";
			}
			Object sequence = db.get("sequence");
			Object transactionid = db.get("transactionid");
			Object dashboard = db.get("dashboard");
			if (dashboard != null) {
				ml.setDashboard(dashboard.toString());
			}
			if (activityState != null) {
				if(activityState.equals("INPROGRESS")) {
				ml.setActivityState("COMPLETED");
				}else {
					ml.setActivityState(activityState.toString());
				}
			}
			if (activityTimestamp != null) {
				ml.setActivityTimestamp(activityTimestamp.toString());
			}
			
			if (errorCode != null) {
				ml.setErrorCode(errorCode.toString());
			}
			if (processName != null) {
				ml.setProcessName(processName.toString());
			}
			if (sequence != null) {
				ml.setSequence((Integer) sequence);
			}
			if (transactionid != null) {
				ml.setTransactionid(transactionid.toString());
			}
			if (payload != null) {
				ml.setPayload(payload.toString());
			}
			response.add(ml);
		}
		}
		
		if (response.isEmpty()) {
			throw new NoRecordsException("No Records Found");
		}
		return response;

	}
	
	public void repushAudit(String query) {
		
int maxRetries=1;

		
		
		for(int i=0;i<=maxRetries;i++) {
		
		try {
			 hiveJdbcTemplate.update(query);
			i=maxRetries+1;
		} catch (Exception e) {
			System.out.println("exception" + e+e.getStackTrace());
			
			if(i==1) {
				System.out.println("Bad Input Request");
				}else {
					hiveConnection(false);
				}
			
		}
		}
		
		
		
		
	}

}
