package com.jio.dap.pmapi.exceptions;


public class NoRecordsException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NoRecordsException(String errorMessage) {
        super(errorMessage);
    }

}
