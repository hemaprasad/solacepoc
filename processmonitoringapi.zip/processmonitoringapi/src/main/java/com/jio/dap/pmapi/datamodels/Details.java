package com.jio.dap.pmapi.datamodels;

public class Details {
	private String processname;
	private String processtype;
	private String processstate;
	private String activitystate;
	private String activitytimestamp;
	private String errorcode;
	public String getProcessname() {
		return processname;
	}
	public void setProcessname(String processname) {
		this.processname = processname;
	}
	public String getProcesstype() {
		return processtype;
	}
	public void setProcesstype(String processtype) {
		this.processtype = processtype;
	}
	public String getProcessstate() {
		return processstate;
	}
	public void setProcessstate(String processstate) {
		this.processstate = processstate;
	}
	public String getActivitystate() {
		return activitystate;
	}
	public void setActivitystate(String activitystate) {
		this.activitystate = activitystate;
	}
	public String getActivitytimestamp() {
		return activitytimestamp;
	}
	public void setActivitytimestamp(String activitytimestamp) {
		this.activitytimestamp = activitytimestamp;
	}
	public String getErrorcode() {
		return errorcode;
	}
	public void setErrorcode(String errorcode) {
		this.errorcode = errorcode;
	}
	@Override
	public String toString() {
		return "Details [processname=" + processname + ", processtype=" + processtype + ", processstate=" + processstate
				+ ", activitystate=" + activitystate + ", activitytimestamp=" + activitytimestamp + ", errorcode="
				+ errorcode + "]";
	}
	
	
}
