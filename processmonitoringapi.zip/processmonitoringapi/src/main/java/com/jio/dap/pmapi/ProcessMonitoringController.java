package com.jio.dap.pmapi;

import java.io.IOException;
import java.sql.SQLException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.jio.dap.pmapi.config.JsonLoader;
import com.jio.dap.pmapi.dataaccess.ProcessMonitoringInterface;
import com.jio.dap.pmapi.exceptions.FileNotExistException;
import com.jio.dap.pmapi.exceptions.NoRecordsException;




@RestController
@CrossOrigin("*")
public class ProcessMonitoringController {

	@Autowired
	JsonLoader jsonLoader;

	@Autowired
	ProcessMonitoringInterface dashboardInterface;
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/DashboardColumns", method = RequestMethod.POST)
	@ResponseBody
	public JSONObject Columns(@RequestBody JSONObject columnsRequest)
			throws ClassNotFoundException, SQLException, IOException {
		JSONObject columnsResponse = jsonLoader.getObject((String) columnsRequest.get("dashboard"));
		JSONObject response = new JSONObject();
		response.put("parent", columnsResponse.get(columnsRequest.get("parent")));
		response.put("child", columnsResponse.get(columnsRequest.get("child")));

		return response;
	}
	
	 @RequestMapping(value="/DashboardSummary", method = RequestMethod.POST)
	 @ResponseBody
	    public JSONArray Dashboardcall(@RequestBody JSONObject dashboardRequest) throws NoRecordsException, FileNotExistException, IOException {
		 JSONArray dashboardResponse;
		 JSONObject payload=jsonLoader.getObject((String)dashboardRequest.get("dashboard"));

	    	
	    	dashboardResponse=dashboardInterface.SummaryProcess(dashboardRequest, payload);
	    	
	    	
	        return dashboardResponse;
	    }
	 @RequestMapping(value="/DashboardErrorSummary", method = RequestMethod.POST)
	 @ResponseBody
	    public JSONArray DashboarErrordcall(@RequestBody JSONObject dashboardErrorRequest) throws NoRecordsException, FileNotExistException, IOException {
	    	JSONArray dashboardResponse;
			 JSONObject payload=jsonLoader.getObject((String)dashboardErrorRequest.get("dashboard"));

	    	dashboardResponse=dashboardInterface.ErrorSummaryProcess(dashboardErrorRequest,payload);
	    	
	    	
	        return dashboardResponse;
	    }

	@RequestMapping(value = "/Tracking", method = RequestMethod.POST)
	@ResponseBody
	public JSONArray RechargeTrackingcall(@RequestBody JSONObject trackingRequest)
			throws NoRecordsException, FileNotExistException, IOException {
		JSONArray trackingResponse;
		JSONObject payload = jsonLoader.getObject((String) trackingRequest.get("dashboard"));
		
		System.out.println("request recieved" + trackingRequest);
		trackingResponse = dashboardInterface.TrackingProcess(trackingRequest, payload);

		return trackingResponse;
	}
	
	@RequestMapping(value = "/ProcessDetails", method = RequestMethod.POST)
	@ResponseBody
	public JSONObject ProcessDetailsCall(
			@RequestBody JSONObject processDetailsRequest) throws NoRecordsException, FileNotExistException, IOException {
		System.out.println("request" + processDetailsRequest);
		JSONObject processDetailsResponse;
		JSONObject payload = jsonLoader.getObject((String) processDetailsRequest.get("dashboard"));

		processDetailsResponse = dashboardInterface
				.ProcessDetailsProcess(processDetailsRequest,payload);
		return processDetailsResponse;
	}
	
	@RequestMapping(value = "/ErrorTracking", method = RequestMethod.POST)
	public JSONArray ErrorTrackingcall(@RequestBody JSONObject errorTrackingRequest)
			throws NoRecordsException, FileNotExistException, IOException {
		JSONArray errorTrackingResponse;
		JSONObject payload = jsonLoader.getObject((String) errorTrackingRequest.get("dashboard"));

		errorTrackingResponse = dashboardInterface
				.ErrorTrackingProcess(errorTrackingRequest,payload);

		return errorTrackingResponse;
	}
	@RequestMapping(value = "/TrackingLineItems", method = RequestMethod.POST)
	public JSONArray TrackingLineItemscall(@RequestBody JSONObject trackingLineItemsRequest)
			throws NoRecordsException, FileNotExistException, IOException {
		JSONArray trackingLineItemsResponse;
		JSONObject payload = jsonLoader.getObject((String) trackingLineItemsRequest.get("dashboard"));

		trackingLineItemsResponse = dashboardInterface
				.trackingLineItemsProcess(trackingLineItemsRequest,payload);

		return trackingLineItemsResponse;
	}
	
	@RequestMapping(value = "/Repush", method = RequestMethod.POST)
	public JSONArray Repushcall(@RequestBody JSONObject repushRequest)
			throws NoRecordsException, FileNotExistException, IOException {
		JSONArray repushResponse;
		System.out.println("request  "+repushRequest);
		JSONObject payload = jsonLoader.getObject((String) repushRequest.get("dashboard"));
		JSONObject repushPayload = jsonLoader.getRepushObject((String) repushRequest.get("dashboard"));
		JSONObject solaceConfig = jsonLoader.getRepushObject("connections");
		System.out.println("config"+solaceConfig);
		repushResponse = dashboardInterface
				.repushProcess(repushRequest,payload,repushPayload,solaceConfig);

		return repushResponse;
	}
	
	@RequestMapping(value = "/Payload", method = RequestMethod.POST)
	public JSONObject Payloadcall(@RequestBody JSONObject payloadRequest)
			throws NoRecordsException, FileNotExistException, IOException {
		JSONObject payloadResponse ;
		JSONObject payload = jsonLoader.getObject((String) payloadRequest.get("dashboard"));

		payloadResponse = dashboardInterface
				.payloadProcess(payloadRequest,payload);

		return payloadResponse;
	}
}
