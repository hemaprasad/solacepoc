package com.solace.connect;


import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

import javax.annotation.PostConstruct;
import javax.jms.Connection;
import javax.jms.DeliveryMode;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.jms.connection.CachingConnectionFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

import com.solacesystems.jms.SolConnectionFactory;
import com.solacesystems.jms.SolJmsUtility;

@SuppressWarnings("unused")
@Service
public class PublishSubscribe {
	@Value("${solace.replyQueue}")
	private String queueName;
	
	@JmsListener(destination = "${solace.queue}")
	public void handle(Message message) throws Exception {

		Date receiveTime = new Date();
		TextMessage tm = (TextMessage) message;

        System.out.printf("Message Content recieved at subscriber:%n%s%n", SolJmsUtility.dumpMessage(message));

		sendEvent(tm.getText(),message.getJMSCorrelationID(),message.getJMSReplyTo().toString());
	}
	
	
	
	@Autowired
	private JmsTemplate jmsTemplate;

	@PostConstruct
	private void customizeJmsTemplate() {
		// Update the jmsTemplate's connection factory to cache the connection
		CachingConnectionFactory ccf = new CachingConnectionFactory();
		ccf.setTargetConnectionFactory(jmsTemplate.getConnectionFactory());
		jmsTemplate.setConnectionFactory(ccf);

		// By default Spring Integration uses Queues, but if you set this to true you
		// will send to a PubSub+ topic destination
		jmsTemplate.setPubSubDomain(false);
	}

	

	public void sendEvent(String msg,String correlationid, String reply) throws Exception {
		System.out.println("==========SENDING reply MESSAGE========== " + msg+" "+correlationid);
		jmsTemplate.convertAndSend(reply, msg);
		
		
		SolConnectionFactory connectionFactory = SolJmsUtility.createConnectionFactory();
        connectionFactory.setHost("tcp://10.140.102.113:55555");
        connectionFactory.setVPN("ST_O2A_VPN");
        connectionFactory.setUsername("tibcoesb");
        connectionFactory.setPassword("tibcoesb");

        Connection connection = connectionFactory.createConnection();

        Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);

       
        Queue queue = session.createQueue(reply);
        MessageProducer requestProducer = session.createProducer(queue);



        connection.start();

        TextMessage request = session.createTextMessage(msg);
     
        request.setJMSCorrelationID(correlationid);
        request.setJMSExpiration(1000);
        
        


        // Send the request
        requestProducer.send(queue, request, DeliveryMode.NON_PERSISTENT,
                Message.DEFAULT_PRIORITY,
                Message.DEFAULT_TIME_TO_LIVE);

	}

}
